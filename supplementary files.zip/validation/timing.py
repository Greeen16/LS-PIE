"""Dedicated wall-clock benchmark for the four post-processing conditions, on both
datasets used in the paper.

Why this exists separately from validation.py / ecg_validation.py: those scripts
time each fit inside their bootstrap loop and summarise as mean +/- s.d. Fit times
here are heavy-tailed - FastICA occasionally exhausts max_iter without converging,
and Latent Expansion refits from scratch at every step, so one non-converging refit
dominates the mean. A mean +/- s.d. over that distribution is not a usable summary
(the v1.4 manuscript reported one whose standard deviation exceeded its mean by
more than an order of magnitude). This script reports the median and interquartile
range instead, measured on an otherwise idle machine.

Writes timing_results.json.
"""
import json
import os
import sys
import time
import warnings

warnings.filterwarnings("ignore")

import numpy as np
from scipy import signal as spsignal
from sklearn.cluster import Birch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "lspie_src"))

from functions import prebuiltICA, innerProduct, absInnerProduct  # noqa: E402
import LSPIE  # noqa: E402

SEED = 12345
CONDITIONS = ["None", "Ranked Scaling", "Latent Expansion", "Latent Condensing"]
N_COMPONENTS = 4
LEXP_MAXCOMP = 8
LEXP_CUTOFF = 0.1
LCON_N_CLUSTERS = 3

# toy problem (matches datagen.paperExamplegen and Section 3.1)
TOY_T = np.linspace(0, 1, 800)
TOY_CHANNELS = 20
TOY_NOISE = 0.3

# ECG (matches Section 3.3)
ECG_SAMPLES = 187
ECG_CHANNELS = 20

N_REPEATS = {"toy": 60, "ecg": 200}


def toy_trial(kind, rng):
    cols = []
    for _ in range(TOY_CHANNELS):
        scaler = rng.random()
        noise = rng.random(len(TOY_T)) * TOY_NOISE
        if kind == "saw":
            sig = spsignal.sawtooth(2 * np.pi * 3 * TOY_T) * scaler + noise
        else:
            sig = np.sin(2 * np.pi * TOY_T) * scaler + noise
        cols.append(sig)
    return np.array(cols).T


def ecg_trial(beats, rng):
    idx = rng.choice(beats.shape[0], size=ECG_CHANNELS, replace=False)
    return beats[idx].T.copy()


def none_baseline(data, n):
    comps = prebuiltICA(data, n)
    ref = data.mean(axis=1)
    s = np.array([abs(innerProduct(ref, c)) for c in comps])
    return comps, np.abs(s) / np.sum(np.abs(s)) * 100


def fit_condition(condition, data):
    if condition == "None":
        return none_baseline(data, N_COMPONENTS)
    if condition == "Ranked Scaling":
        proc = LSPIE.processor("LRS", prebuiltICA, innerProduct)
        proc.fit(data, N_COMPONENTS, False)
    elif condition == "Latent Expansion":
        proc = LSPIE.processor("LEXP", prebuiltICA, innerProduct)
        proc.fit(data, LEXP_MAXCOMP, LEXP_CUTOFF, False)
    elif condition == "Latent Condensing":
        proc = LSPIE.processor("LCON", prebuiltICA, absInnerProduct)
        proc.fit(data, Birch(n_clusters=LCON_N_CLUSTERS), 1, False)
    else:
        raise ValueError(condition)
    return np.asarray(proc.components), np.asarray(proc.scores)


def summarise(samples_ms):
    a = np.asarray(samples_ms, dtype=float)
    q1, med, q3 = np.percentile(a, [25, 50, 75])
    return dict(median_ms=float(med), q1_ms=float(q1), q3_ms=float(q3),
                iqr_ms=float(q3 - q1), mean_ms=float(a.mean()), std_ms=float(a.std()),
                min_ms=float(a.min()), max_ms=float(a.max()), n=int(a.size))


def bench(name, make_trial, n_repeats):
    rng = np.random.default_rng(SEED)
    np.random.seed(SEED)
    trials = [make_trial(rng) for _ in range(n_repeats)]
    # warm-up so the first measured fit does not carry import/JIT/allocator cost
    for c in CONDITIONS:
        fit_condition(c, trials[0])
    out = {}
    for c in CONDITIONS:
        times = []
        for X in trials:
            t0 = time.perf_counter()
            fit_condition(c, X)
            times.append((time.perf_counter() - t0) * 1000.0)
        out[c] = summarise(times)
        s = out[c]
        print(f"  {name:4s} {c:18s} median {s['median_ms']:9.2f} ms "
              f"[IQR {s['q1_ms']:8.2f}-{s['q3_ms']:9.2f}]  "
              f"mean {s['mean_ms']:9.2f} +/- {s['std_ms']:9.2f}  max {s['max_ms']:9.1f}",
              flush=True)
    return out


def main():
    results = {"meta": dict(seed=SEED, n_repeats=N_REPEATS,
                            note="median/IQR over independent trial matrices, "
                                 "one processor.fit each, warm-up excluded")}

    print("toy problem (800 x 20):")
    rng_kind = {"i": 0}

    def make_toy(rng):
        rng_kind["i"] += 1
        return toy_trial("saw" if rng_kind["i"] % 2 else "sin", rng)

    results["toy"] = bench("toy", make_toy, N_REPEATS["toy"])

    ecg_dir = os.path.join(HERE, "ecg_data")
    normal = np.loadtxt(os.path.join(ecg_dir, "ptbdb_normal.csv"),
                        delimiter=",")[:, :ECG_SAMPLES]
    abnormal = np.loadtxt(os.path.join(ecg_dir, "ptbdb_abnormal.csv"),
                          delimiter=",")[:, :ECG_SAMPLES]
    print("ECG (187 x 20):")
    ecg_kind = {"i": 0}

    def make_ecg(rng):
        ecg_kind["i"] += 1
        return ecg_trial(normal if ecg_kind["i"] % 2 else abnormal, rng)

    results["ecg"] = bench("ecg", make_ecg, N_REPEATS["ecg"])

    with open(os.path.join(HERE, "timing_results.json"), "w") as f:
        json.dump(results, f, indent=2)
    print("\nwritten to timing_results.json")


if __name__ == "__main__":
    main()
