"""
Real-ECG statistical validation and quantitative metrics for the LS-PIE revision.

This is the ECG counterpart of validation.py.  Where validation.py used a
synthetic two-class proxy (because the ECG data referenced by the paper's
notebook lives behind a hardcoded local Windows path), this script runs the
identical analysis on the actual ECG corpus the notebook was written against:
the PTB Diagnostic ECG Database segmented-heartbeat release
(ptbdb_normal.csv / ptbdb_abnormal.csv), which is the dataset whose file names
and 4-file glob order match `keys[2] -> abnormal`, `keys[3] -> normal` in
"LSPIE Module.ipynb" (LS-PIE-2026 branch, commit d6bda66).

Each CSV row is one segmented heartbeat: 187 samples at 125 Hz (zero-padded to
a fixed length) followed by a class label in the final column.

  ptbdb_normal.csv    normal    beats
  ptbdb_abnormal.csv  abnormal  beats (myocardial infarction)

WHAT IS REPORTED
  1. Table 1 replacement on REAL data: Mann-Whitney U and Welch t-test
     comparing normal vs abnormal populations of independent trial matrices
     under None / Ranked Scaling (LRS) / Latent Expansion (LEXP) / Latent
     Condensing (LCON), following the paper's stated methodology (15 repeated
     sub-samples of 500 trials), with rank-biserial and Cohen's d effect
     sizes, 95% confidence intervals, and Holm-Bonferroni correction.
  2. Runtime per method (wall-clock, mean +/- std).
  3. Compression ratio (# retained components / # initially solved).
  4. Reconstruction error: relative Frobenius error of the least-squares
     projection of the trial matrix onto the retained component subspace.
  5. Downstream classification: normal-vs-abnormal logistic regression on the
     top-k score vector produced by each condition (5-fold stratified CV,
     accuracy + ROC AUC).  This is the "downstream classification performance"
     metric requested by Reviewer 1.
  6. Orientation diagnostic: reproduces the original notebook's call pattern
     (a raw beats x samples DataFrame handed straight to processor.fit) to
     show what the original Table 1 was actually measuring.

TRIAL CONSTRUCTION
  A "trial" is one (187 x N_CHANNELS) matrix built from N_CHANNELS heartbeats
  drawn at random (without replacement within a trial) from a single class.
  This is the direct ECG analogue of the toy problem's (800 x n_channels)
  matrix of independent realisations, and keeps the data orientation
  (rows = time samples, columns = observation channels) consistent with every
  other experiment in the paper.

All numbers are printed as JSON to stdout and written to ecg_results.json.
"""
import warnings
warnings.filterwarnings("ignore")

import json
import os
import sys
import time

import numpy as np
from scipy import stats as spstats
from sklearn.cluster import Birch
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "lspie_src"))

from functions import prebuiltICA, innerProduct, absInnerProduct  # noqa: E402
import LSPIE  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(HERE, "ecg_data")
NORMAL_CSV = os.path.join(DATA_DIR, "ptbdb_normal.csv")
ABNORMAL_CSV = os.path.join(DATA_DIR, "ptbdb_abnormal.csv")

RNG_SEED = 12345
N_SAMPLES = 187           # signal samples per beat (final column is the label)
N_CHANNELS = 20           # beats per trial matrix; matches the toy-problem setup
N_COMPONENTS = 4          # matches "we restrict it to four components" (ECG section)
N_BOOT = 1000             # independent trial matrices per class
N_SUBSAMPLE_SETS = 15     # matches paper's stated methodology
SUBSAMPLE_SIZE = 500      # matches paper's stated methodology
LEXP_MAXCOMP = 8
LEXP_CUTOFF = 0.1
LCON_N_CLUSTERS = 3

CONDITIONS = ["None", "Ranked Scaling", "Latent Expansion", "Latent Condensing"]


# --------------------------------------------------------------------------
# Data
# --------------------------------------------------------------------------
def load_class(path):
    """Load one PTBDB class file -> (n_beats, 187) float array (label dropped).

    The released CSVs are headerless; the notebook's pd.read_csv(f) default
    silently consumed the first beat as a header row.  We read all rows.
    """
    arr = np.loadtxt(path, delimiter=",", dtype=np.float64)
    assert arr.shape[1] == N_SAMPLES + 1, f"unexpected width {arr.shape} in {path}"
    labels = np.unique(arr[:, -1])
    return arr[:, :N_SAMPLES], labels


def make_trial(beats, rng, n_ch=N_CHANNELS):
    """One (187 x n_ch) trial matrix: n_ch distinct beats from one class,
    rows = time samples, columns = observation channels."""
    idx = rng.choice(beats.shape[0], size=n_ch, replace=False)
    return beats[idx].T.copy()


# --------------------------------------------------------------------------
# Conditions (identical semantics to validation.py)
# --------------------------------------------------------------------------
def none_baseline(data, n_components):
    """'None' row: raw FastICA components, scored but NOT ranked/scaled/clustered."""
    comps = prebuiltICA(data, n_components)
    ref = data.mean(axis=1)
    scores = np.array([abs(innerProduct(ref, c)) for c in comps])
    tot = np.sum(np.abs(scores))
    scores = np.abs(scores) / tot * 100
    return comps, scores


def fit_condition(condition, data):
    """Return (components, scores) for one condition on one trial matrix."""
    if condition == "None":
        return none_baseline(data, N_COMPONENTS)
    if condition == "Ranked Scaling":
        proc = LSPIE.processor("LRS", prebuiltICA, innerProduct)
        proc.fit(data, N_COMPONENTS, False)
        return np.asarray(proc.components), np.asarray(proc.scores)
    if condition == "Latent Expansion":
        proc = LSPIE.processor("LEXP", prebuiltICA, innerProduct)
        proc.fit(data, LEXP_MAXCOMP, LEXP_CUTOFF, False)
        scores = np.asarray(proc.scores)
        scores = scores * 100 if np.max(scores) <= 1.0001 else scores
        return np.asarray(proc.components), scores
    if condition == "Latent Condensing":
        cmodel = Birch(n_clusters=LCON_N_CLUSTERS)
        proc = LSPIE.processor("LCON", prebuiltICA, absInnerProduct)
        proc.fit(data, cmodel, 1, False)
        return np.asarray(proc.components), np.asarray(proc.scores)
    raise ValueError(condition)


def top_k_scores(scores, k=N_COMPONENTS):
    s = np.sort(np.asarray(scores, dtype=float))[::-1]
    out = np.full(k, np.nan)
    out[: min(k, len(s))] = s[: min(k, len(s))]
    return out


def n_solved(condition, n_ch=N_CHANNELS):
    """Number of components the underlying LVM was asked to solve for."""
    if condition in ("None", "Ranked Scaling"):
        return N_COMPONENTS
    if condition == "Latent Expansion":
        return LEXP_MAXCOMP
    if condition == "Latent Condensing":
        # fitLCON asks for 10*min(shape); FastICA caps at min(shape) = n_ch
        return n_ch
    raise ValueError(condition)


def reconstruction_error(data, components):
    """Relative Frobenius error of the least-squares projection of `data`
    onto the row space of the retained components."""
    C = np.asarray(components, dtype=float)
    if C.ndim == 1:
        C = C[None, :]
    if C.shape[1] != data.shape[0]:
        C = C.T
    # data (T x n_ch); C (k x T).  Project columns of data onto span(C^T).
    B = C.T                                   # (T x k)
    coef, *_ = np.linalg.lstsq(B, data, rcond=None)
    approx = B @ coef
    denom = np.linalg.norm(data, "fro")
    return float(np.linalg.norm(data - approx, "fro") / denom) if denom > 0 else np.nan


# --------------------------------------------------------------------------
# Statistics
# --------------------------------------------------------------------------
def welch_stats(a, b):
    a = a[~np.isnan(a)]
    b = b[~np.isnan(b)]
    if len(a) < 2 or len(b) < 2:
        return dict(t=np.nan, p=np.nan, df=np.nan, d=np.nan, n1=len(a), n2=len(b))
    res = spstats.ttest_ind(a, b, equal_var=False)
    v1, v2 = np.var(a, ddof=1), np.var(b, ddof=1)
    n1, n2 = len(a), len(b)
    df = (v1 / n1 + v2 / n2) ** 2 / ((v1 / n1) ** 2 / (n1 - 1) + (v2 / n2) ** 2 / (n2 - 1))
    d = (np.mean(a) - np.mean(b)) / np.sqrt((v1 + v2) / 2)
    return dict(t=float(res.statistic), p=float(res.pvalue), df=float(df),
                d=float(d), n1=n1, n2=n2)


def mwu_stats(a, b):
    a = a[~np.isnan(a)]
    b = b[~np.isnan(b)]
    if len(a) < 2 or len(b) < 2:
        return dict(U=np.nan, p=np.nan, r_rb=np.nan, n1=len(a), n2=len(b))
    res = spstats.mannwhitneyu(a, b, alternative="two-sided")
    n1, n2 = len(a), len(b)
    r_rb = 1 - (2 * float(res.statistic)) / (n1 * n2)
    return dict(U=float(res.statistic), p=float(res.pvalue), r_rb=float(r_rb),
                n1=n1, n2=n2)


def welch_ci(a, b, alpha=0.05):
    """95% CI for the difference in means (Welch) and for Cohen's d."""
    a = a[~np.isnan(a)]
    b = b[~np.isnan(b)]
    if len(a) < 2 or len(b) < 2:
        return dict(mean_diff=np.nan, ci_low=np.nan, ci_high=np.nan,
                    d=np.nan, d_ci_low=np.nan, d_ci_high=np.nan)
    n1, n2 = len(a), len(b)
    v1, v2 = np.var(a, ddof=1), np.var(b, ddof=1)
    diff = np.mean(a) - np.mean(b)
    se = np.sqrt(v1 / n1 + v2 / n2)
    df = (v1 / n1 + v2 / n2) ** 2 / ((v1 / n1) ** 2 / (n1 - 1) + (v2 / n2) ** 2 / (n2 - 1))
    tcrit = spstats.t.ppf(1 - alpha / 2, df)
    s_pool = np.sqrt((v1 + v2) / 2)
    d = diff / s_pool
    # Hedges' large-sample SE for d
    se_d = np.sqrt((n1 + n2) / (n1 * n2) + d ** 2 / (2 * (n1 + n2 - 2)))
    zcrit = spstats.norm.ppf(1 - alpha / 2)
    return dict(mean_diff=float(diff),
                ci_low=float(diff - tcrit * se), ci_high=float(diff + tcrit * se),
                d=float(d),
                d_ci_low=float(d - zcrit * se_d), d_ci_high=float(d + zcrit * se_d))


def rank_biserial_ci(a, b, alpha=0.05, n_boot=2000, seed=7):
    """Percentile bootstrap 95% CI for the rank-biserial correlation."""
    a = a[~np.isnan(a)]
    b = b[~np.isnan(b)]
    if len(a) < 2 or len(b) < 2:
        return dict(r_rb=np.nan, ci_low=np.nan, ci_high=np.nan)
    rng = np.random.default_rng(seed)
    n1, n2 = len(a), len(b)
    point = 1 - 2 * float(spstats.mannwhitneyu(a, b, alternative="two-sided").statistic) / (n1 * n2)
    reps = np.empty(n_boot)
    for i in range(n_boot):
        aa = a[rng.integers(0, n1, n1)]
        bb = b[rng.integers(0, n2, n2)]
        reps[i] = 1 - 2 * float(spstats.mannwhitneyu(aa, bb, alternative="two-sided").statistic) / (n1 * n2)
    lo, hi = np.percentile(reps, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    return dict(r_rb=float(point), ci_low=float(lo), ci_high=float(hi))


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------
def main():
    np.random.seed(RNG_SEED)          # FastICA / Birch use the global RNG
    rng = np.random.default_rng(RNG_SEED)

    normal, normal_labels = load_class(NORMAL_CSV)
    abnormal, abnormal_labels = load_class(ABNORMAL_CSV)
    print(f"# normal beats:   {normal.shape}  labels={normal_labels}", flush=True)
    print(f"# abnormal beats: {abnormal.shape}  labels={abnormal_labels}", flush=True)

    classes = {"normal": normal, "abnormal": abnormal}

    # ---- 1. Bootstrap pool of per-trial top-k scores per class x condition ----
    pool = {c: {k: np.full((N_BOOT, N_COMPONENTS), np.nan) for k in classes}
            for c in CONDITIONS}
    runtime = {c: [] for c in CONDITIONS}
    recon = {c: {k: [] for k in classes} for c in CONDITIONS}
    retained = {c: {k: [] for k in classes} for c in CONDITIONS}

    t_start = time.time()
    for i in range(N_BOOT):
        trials = {k: make_trial(v, rng) for k, v in classes.items()}
        for c in CONDITIONS:
            for k, X in trials.items():
                t0 = time.time()
                comps, scores = fit_condition(c, X)
                runtime[c].append(time.time() - t0)
                pool[c][k][i] = top_k_scores(scores)
                retained[c][k].append(int(len(np.atleast_1d(scores))))
                if i < 100:      # reconstruction error on the first 100 trials
                    recon[c][k].append(reconstruction_error(X, comps))
        if (i + 1) % 100 == 0:
            print(f"#   {i+1}/{N_BOOT} trials  ({time.time()-t_start:.0f}s)", flush=True)
    print(f"# bootstrap pool built in {time.time()-t_start:.1f}s", flush=True)

    # ---- 2. Paper's stated procedure: 15 subsamples of 500, per component rank ----
    table = {}
    for c in CONDITIONS:
        mwu_runs = {k: [] for k in range(N_COMPONENTS)}
        tt_runs = {k: [] for k in range(N_COMPONENTS)}
        for _ in range(N_SUBSAMPLE_SETS):
            idx_n = rng.choice(N_BOOT, size=SUBSAMPLE_SIZE, replace=False)
            idx_a = rng.choice(N_BOOT, size=SUBSAMPLE_SIZE, replace=False)
            for k in range(N_COMPONENTS):
                a = pool[c]["normal"][idx_n, k]
                b = pool[c]["abnormal"][idx_a, k]
                mwu_runs[k].append(mwu_stats(a, b))
                tt_runs[k].append(welch_stats(a, b))

        table[c] = {"mwu": {}, "ttest": {}, "ci": {}}
        for k in range(N_COMPONENTS):
            Us = [r["U"] for r in mwu_runs[k] if not np.isnan(r["U"])]
            Ps = [r["p"] for r in mwu_runs[k] if not np.isnan(r["p"])]
            Rs = [r["r_rb"] for r in mwu_runs[k] if not np.isnan(r["r_rb"])]
            Ns = [r["n1"] for r in mwu_runs[k] if not np.isnan(r["U"])]
            table[c]["mwu"][k] = dict(
                U_median=float(np.median(Us)) if Us else None,
                p_median=float(np.median(Ps)) if Ps else None,
                p_min=float(np.min(Ps)) if Ps else None,
                p_max=float(np.max(Ps)) if Ps else None,
                r_rb_median=float(np.median(Rs)) if Rs else None,
                n_median=float(np.median(Ns)) if Ns else None,
                n_replicates=len(Ps),
            )
            Ts = [r["t"] for r in tt_runs[k] if not np.isnan(r["t"])]
            Pt = [r["p"] for r in tt_runs[k] if not np.isnan(r["p"])]
            Dt = [r["df"] for r in tt_runs[k] if not np.isnan(r["df"])]
            Cd = [r["d"] for r in tt_runs[k] if not np.isnan(r["d"])]
            Nt = [r["n1"] for r in tt_runs[k] if not np.isnan(r["t"])]
            table[c]["ttest"][k] = dict(
                t_median=float(np.median(Ts)) if Ts else None,
                p_median=float(np.median(Pt)) if Pt else None,
                p_min=float(np.min(Pt)) if Pt else None,
                p_max=float(np.max(Pt)) if Pt else None,
                df_median=float(np.median(Dt)) if Dt else None,
                d_median=float(np.median(Cd)) if Cd else None,
                n_median=float(np.median(Nt)) if Nt else None,
                n_replicates=len(Pt),
            )
            # CIs on the FULL pool (n = N_BOOT per class), not per-subsample
            a_full = pool[c]["normal"][:, k]
            b_full = pool[c]["abnormal"][:, k]
            ci = welch_ci(a_full, b_full)
            ci.update({"r_rb_" + kk: vv for kk, vv in rank_biserial_ci(a_full, b_full).items()})
            ci["n1_full"] = int(np.sum(~np.isnan(a_full)))
            ci["n2_full"] = int(np.sum(~np.isnan(b_full)))
            table[c]["ci"][k] = ci

        # Holm-Bonferroni across the component-rank family within each condition
        for test in ("mwu", "ttest"):
            entries = [(k, table[c][test][k]["p_median"]) for k in range(N_COMPONENTS)
                       if table[c][test][k]["p_median"] is not None]
            entries.sort(key=lambda kv: kv[1])
            m = len(entries)
            for rank, (k, p) in enumerate(entries):
                table[c][test][k]["p_holm"] = float(min(1.0, p * (m - rank)))

    # ---- 3. Runtime ----
    runtime_summary = {c: dict(mean_ms=float(np.mean(runtime[c]) * 1000),
                               std_ms=float(np.std(runtime[c]) * 1000),
                               n=len(runtime[c]))
                       for c in CONDITIONS}

    # ---- 4. Compression + reconstruction error ----
    compression = {}
    reconstruction = {}
    for c in CONDITIONS:
        for k in classes:
            r = np.array(retained[c][k], dtype=float)
            solved = n_solved(c)
            compression[f"{c}|{k}"] = dict(
                n_retained_mean=float(np.mean(r)),
                n_retained_median=float(np.median(r)),
                n_solved=solved,
                compression_ratio=float(np.mean(r) / solved),
            )
            e = np.array(recon[c][k], dtype=float)
            reconstruction[f"{c}|{k}"] = dict(
                rel_frobenius_error_mean=float(np.mean(e)),
                rel_frobenius_error_std=float(np.std(e)),
                n=int(e.size),
            )

    # ---- 5. Downstream classification on the top-k score vectors ----
    downstream = {}
    for c in CONDITIONS:
        X = np.vstack([pool[c]["normal"], pool[c]["abnormal"]])
        y = np.concatenate([np.zeros(N_BOOT), np.ones(N_BOOT)])
        # A missing rank (e.g. LCON retains only 3 components) means "no
        # component contributes at this rank" -> encode as a 0% score rather
        # than discarding the trial.  Then drop ranks that are constant.
        X = np.nan_to_num(X, nan=0.0)
        keep = X.std(axis=0) > 0
        X = X[:, keep]
        ok = np.isfinite(X).all(axis=1)
        X, y = X[ok], y[ok]
        clf = make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000))
        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RNG_SEED)
        sc = cross_validate(clf, X, y, cv=cv, scoring=["accuracy", "roc_auc"])
        downstream[c] = dict(
            accuracy_mean=float(np.mean(sc["test_accuracy"])),
            accuracy_std=float(np.std(sc["test_accuracy"])),
            roc_auc_mean=float(np.mean(sc["test_roc_auc"])),
            roc_auc_std=float(np.std(sc["test_roc_auc"])),
            n_features=int(X.shape[1]),
            n_samples=int(X.shape[0]),
        )

    # ---- 6. Orientation diagnostic (reproduces the original notebook call) ----
    orientation = {}
    for c in CONDITIONS:
        for k, beats in classes.items():
            try:
                comps, scores = fit_condition(c, beats)   # raw (n_beats x 187), as in the notebook
                orientation[f"{c}|{k}"] = dict(
                    input_shape=list(beats.shape),
                    component_length=int(np.asarray(comps).shape[-1]),
                    top_scores=[float(v) for v in top_k_scores(scores)],
                )
            except Exception as exc:                       # pragma: no cover
                orientation[f"{c}|{k}"] = dict(error=repr(exc))

    results = dict(
        meta=dict(
            dataset="PTB Diagnostic ECG Database, segmented-heartbeat release "
                    "(ptbdb_normal.csv / ptbdb_abnormal.csv)",
            lspie_commit="d6bda6684d428a3bce6bc5202ef69217ba9bf78c (branch LS-PIE-2026)",
            seed=RNG_SEED, n_boot=N_BOOT, n_subsample_sets=N_SUBSAMPLE_SETS,
            subsample_size=SUBSAMPLE_SIZE, n_channels=N_CHANNELS,
            n_samples_per_beat=N_SAMPLES, n_components=N_COMPONENTS,
            lexp_maxcomp=LEXP_MAXCOMP, lexp_cutoff=LEXP_CUTOFF,
            lcon_n_clusters=LCON_N_CLUSTERS,
            n_beats_normal=int(normal.shape[0]), n_beats_abnormal=int(abnormal.shape[0]),
            numpy=np.__version__, scipy=spstats.__name__ and __import__("scipy").__version__,
            sklearn=__import__("sklearn").__version__,
        ),
        table=table,
        runtime_ms=runtime_summary,
        compression=compression,
        reconstruction=reconstruction,
        downstream_classification=downstream,
        orientation_diagnostic=orientation,
    )
    out = os.path.join(HERE, "ecg_results.json")
    with open(out, "w") as f:
        json.dump(results, f, indent=2)
    print(json.dumps(results, indent=2))
    print(f"\n# written to {out}", file=sys.stderr)


if __name__ == "__main__":
    main()
