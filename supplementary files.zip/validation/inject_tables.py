"""Render every Results table in the manuscript from the JSON produced by the
driver scripts, replacing the marked blocks in paper_latex/lspie_primer.tex.

  validation_results.json   <- validation.py        (synthetic, Section 3.1-3.2)
  ecg_results.json          <- ecg_validation.py    (ECG, Section 3.3)
  timing_results.json       <- timing.py            (runtime column of both cost tables)

Nothing in the Results tables is typed by hand, so the manuscript cannot drift
from the runs that produced it. Re-run a driver, re-run this, and the paper is
back in sync.

Runtime is taken from timing.py rather than from the bootstrap loops in the two
validation scripts: fit times are heavy-tailed (FastICA occasionally exhausts
max_iter, and Latent Expansion refits from scratch at each step), so the median
and interquartile range are reported instead of a mean and standard deviation.
"""
import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
TEX = os.path.join(HERE, "paper_latex", "lspie_primer.tex")

TOY = json.load(open(os.path.join(HERE, "validation_results.json")))
ECG = json.load(open(os.path.join(HERE, "ecg_results.json")))
TIME = json.load(open(os.path.join(HERE, "timing_results.json")))

CONDS = ["None", "Ranked Scaling", "Latent Expansion", "Latent Condensing"]
LABEL = {"None": "None (raw FastICA)", "Ranked Scaling": "Ranked Scaling (LRS)",
         "Latent Expansion": "Latent Expansion", "Latent Condensing": "Latent Condensing"}


def pfmt(x):
    if x is None:
        return "--"
    if x < 1e-3:
        m, e = f"{x:.1e}".split("e")
        return rf"${m}\times10^{{{int(e)}}}$"
    return f"{x:.3f}"


def sgn(x, n=2):
    return "--" if x is None else f"${x:+.{n}f}$"


def runtime_cell(dataset, cond):
    s = TIME[dataset][cond]
    return rf"${s['median_ms']:.2f}$ [{s['q1_ms']:.2f}--{s['q3_ms']:.2f}]"


def stat_tables(res, tag, labels, caption_class, note=None):
    """Mann-Whitney table + Welch table for one experiment."""
    out = []
    lo, hi = labels
    out.append(r"\begin{table}[H]")
    out.append(r"\small")
    out.append(rf"\caption{{Mann--Whitney $U$ comparison, {caption_class}, by ranked")
    out.append(r"component. Median over 15 independent sub-samples of 500 trials per class;")
    out.append(r"$p_{\mathrm{Holm}}$ is Holm--Bonferroni corrected across the component family")
    out.append(r"within each condition. $r_{\mathrm{rb}}$ is the rank-biserial correlation.")
    if tag == "ecg":
        out.append(r"The 95\% confidence interval is a percentile bootstrap on the full pool of")
        out.append(r"1000 trials per class.")
    out.append(rf"\label{{tab:{tag}mwu}}}}")
    out.append(r"\begin{adjustwidth}{-\extralength}{0cm}")
    ncol = "lCCCCCC" if tag == "ecg" else "lCCCCC"
    out.append(rf"\begin{{tabularx}}{{\fulllength}}{{{ncol}}}")
    out.append(r"\toprule")
    hdr = (r"\textbf{Condition} & \textbf{Comp.} & \textbf{n} & \textbf{U} & "
           r"\textbf{\textit{p} (Holm)} & \textbf{\textit{r}\textsubscript{rb}}")
    if tag == "ecg":
        hdr += r" & \textbf{95\% CI}"
    out.append(hdr + r"\\")
    out.append(r"\midrule")
    for i, c in enumerate(CONDS):
        for k in range(4):
            mw = res["table"][c]["mwu"][str(k)]
            if mw["p_median"] is None:
                continue
            row = (rf"{LABEL[c]} & {k+1} & {mw['n_median']:.0f} & {mw['U_median']:,.0f} & "
                   rf"{pfmt(mw['p_holm'])} & {sgn(mw['r_rb_median'])}")
            if tag == "ecg":
                ci = res["table"][c]["ci"][str(k)]
                row += rf" & $[{ci['r_rb_ci_low']:+.2f},\,{ci['r_rb_ci_high']:+.2f}]$"
            out.append(row + r"\\")
        if i != len(CONDS) - 1:
            out.append(r"\midrule")
    out.append(r"\bottomrule")
    out.append(r"\end{tabularx}")
    if note:
        out.append(rf"\noindent{{\footnotesize {note}}}")
    out.append(r"\end{adjustwidth}")
    out.append(r"\end{table}")
    out.append("")

    out.append(r"\begin{table}[H]")
    out.append(r"\small")
    out.append(rf"\caption{{Welch two-sample $t$-test, {caption_class}, by ranked component,")
    out.append(r"with Welch--Satterthwaite degrees of freedom.")
    if tag == "ecg":
        out.append(r"Cohen's $d$ and its 95\% confidence interval are computed on the full pool")
        out.append(r"of 1000 trials per class.")
    out.append(rf"\label{{tab:{tag}welch}}}}")
    out.append(r"\begin{adjustwidth}{-\extralength}{0cm}")
    ncol = "lCCCCCC" if tag == "ecg" else "lCCCCC"
    out.append(rf"\begin{{tabularx}}{{\fulllength}}{{{ncol}}}")
    out.append(r"\toprule")
    hdr = (r"\textbf{Condition} & \textbf{Comp.} & \textbf{t} & \textbf{df} & "
           r"\textbf{\textit{p} (Holm)} & \textbf{Cohen's \textit{d}}")
    if tag == "ecg":
        hdr += r" & \textbf{95\% CI}"
    out.append(hdr + r"\\")
    out.append(r"\midrule")
    for i, c in enumerate(CONDS):
        for k in range(4):
            tt = res["table"][c]["ttest"][str(k)]
            if tt["p_median"] is None:
                continue
            d = (res["table"][c]["ci"][str(k)]["d"] if tag == "ecg" else tt["d_median"])
            row = (rf"{LABEL[c]} & {k+1} & {tt['t_median']:+.2f} & {tt['df_median']:.1f} & "
                   rf"{pfmt(tt['p_holm'])} & {sgn(d)}")
            if tag == "ecg":
                ci = res["table"][c]["ci"][str(k)]
                row += rf" & $[{ci['d_ci_low']:+.2f},\,{ci['d_ci_high']:+.2f}]$"
            out.append(row + r"\\")
        if i != len(CONDS) - 1:
            out.append(r"\midrule")
    out.append(r"\bottomrule")
    out.append(r"\end{tabularx}")
    out.append(r"\end{adjustwidth}")
    out.append(r"\end{table}")
    return out


def toy_cost_table():
    out = []
    out.append(r"\begin{table}[H]")
    out.append(r"\small")
    out.append(r"\caption{Runtime, compression, and source-recovery correlation on the toy")
    out.append(r"problem. Runtime is the median wall-clock time for a single \texttt{fit} on one")
    out.append(r"$800\times20$ trial matrix, with the interquartile range in brackets, over")
    out.append(rf"{TIME['meta']['n_repeats']['toy']} independent trials on an otherwise idle single core.")
    out.append(r"Compression is the number of components retained relative to the number")
    out.append(r"requested. Recovery correlation is $|r|$ between each condition's top-ranked")
    out.append(r"component and the known ground-truth source.\label{tab2}}")
    out.append(r"\begin{adjustwidth}{-\extralength}{0cm}")
    out.append(r"\begin{tabularx}{\fulllength}{lCCC}")
    out.append(r"\toprule")
    out.append(r"\textbf{Condition} & \textbf{Runtime (ms)} & \textbf{Requested $\rightarrow$ Retained} & \textbf{$|r|$ to True Source}\\")
    out.append(r"\midrule")
    for c in CONDS:
        saw = TOY["compression"][f"{c}|saw"]
        sin = TOY["compression"][f"{c}|sin"]
        req = saw["n_initial_request"]
        lo, hi = sorted({saw["n_solved"], sin["n_solved"]})[0], sorted({saw["n_solved"], sin["n_solved"]})[-1]
        ret = f"{lo}" if lo == hi else f"{lo}--{hi}"
        rs = TOY["recovery_correlation"][f"{c}|saw"]
        rn = TOY["recovery_correlation"][f"{c}|sin"]
        r_lo, r_hi = min(rs, rn), max(rs, rn)
        out.append(rf"{LABEL[c]} & {runtime_cell('toy', c)} & ${req} \rightarrow {ret}$ & "
                   rf"{r_lo:.3f}--{r_hi:.3f}\\")
    out.append(r"\bottomrule")
    out.append(r"\end{tabularx}")
    out.append(r"\end{adjustwidth}")
    out.append(r"\end{table}")
    return out


def ecg_cost_table():
    out = []
    out.append(r"\begin{table}[H]")
    out.append(r"\small")
    out.append(r"\caption{Cost and quality measurements per post-processing condition on the PTB")
    out.append(r"heartbeat data. Runtime is the median wall-clock time for a single \texttt{fit}")
    out.append(r"on one $187\times20$ trial matrix, with the interquartile range in brackets, over")
    out.append(rf"{TIME['meta']['n_repeats']['ecg']} independent trials on an otherwise idle single core.")
    out.append(r"Compression ratio is the mean number of retained components divided by the number")
    out.append(r"the LVM was asked to solve for. Reconstruction error is the relative Frobenius")
    out.append(r"error of the least-squares projection of the trial matrix onto the retained")
    out.append(r"component subspace, so lower is better. Downstream AUC is logistic regression on")
    out.append(r"the score vector under 5-fold stratified cross-validation, where chance is")
    out.append(r"0.500.\label{tab:ecgquant}}")
    out.append(r"\begin{adjustwidth}{-\extralength}{0cm}")
    out.append(r"\begin{tabularx}{\fulllength}{lCCCCC}")
    out.append(r"\toprule")
    out.append(r"\textbf{Condition} & \textbf{Runtime (ms)} & \textbf{Solved $\rightarrow$ Retained} & \textbf{Compression Ratio} & \textbf{Recon. Error} & \textbf{Downstream AUC}\\")
    out.append(r"\midrule")
    for c in CONDS:
        cn, ca = ECG["compression"][f"{c}|normal"], ECG["compression"][f"{c}|abnormal"]
        en, ea = ECG["reconstruction"][f"{c}|normal"], ECG["reconstruction"][f"{c}|abnormal"]
        d = ECG["downstream_classification"][c]
        ret = (cn["n_retained_mean"] + ca["n_retained_mean"]) / 2
        ratio = (cn["compression_ratio"] + ca["compression_ratio"]) / 2
        err = (en["rel_frobenius_error_mean"] + ea["rel_frobenius_error_mean"]) / 2
        out.append(
            rf"{LABEL[c]} & {runtime_cell('ecg', c)} & "
            rf"${cn['n_solved']} \rightarrow {ret:.2f}$ & {ratio:.3f} & {err:.3f} & "
            rf"${d['roc_auc_mean']:.3f}\pm{d['roc_auc_std']:.3f}$\\")
    out.append(r"\bottomrule")
    out.append(r"\end{tabularx}")
    out.append(r"\end{adjustwidth}")
    out.append(r"\end{table}")
    return out


BLOCKS = {
    "TOY-STAT-TABLES": stat_tables(
        TOY, "toy", ("sawtooth", "sinusoid"),
        "sawtooth-class vs.\\ sinusoid-class",
        note="Latent Expansion stops before a third component in most trials for this "
             "well-separated problem, and Latent Condensing's three-cluster target caps it "
             "at three, so those rows end early."),
    "TOY-COST-TABLE": toy_cost_table(),
    "ECG-TABLES": stat_tables(
        ECG, "ecg", ("normal", "abnormal"),
        "normal vs.\\ abnormal PTB heartbeats",
        note="Latent Condensing returns three clusters, and Latent Expansion stops before a "
             "fourth component in a fraction of trials, so those rows end early; the reduced "
             "n for Latent Expansion at ranks 3 and 4 is the number of trials in which a "
             "component of that rank existed.") + [""] + ecg_cost_table(),
}

src = open(TEX).read()
for name, lines in BLOCKS.items():
    begin, end = f"% BEGIN-GENERATED-{name}", f"% END-GENERATED-{name}"
    pattern = re.escape(begin) + r".*?" + re.escape(end)
    body = begin + "\n" + "\n".join(lines) + "\n" + end
    src, n = re.subn(pattern, lambda _m: body, src, flags=re.S)
    assert n == 1, f"marker {name} not found exactly once (found {n})"
    print(f"  {name}: {len(lines)} lines")
open(TEX, "w").write(src)
print(f"wrote {TEX}")
