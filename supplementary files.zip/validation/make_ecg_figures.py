"""Regenerate Figures 9-13 (the ECG demonstration) as publication-quality vector PDFs.

Two things are fixed relative to the figures embedded in the DOCX:

  1. Orientation. The original notebook passed the raw (beats x samples) DataFrame
     straight to processor.fit, so FastICA read the beat index as the sample axis
     and the recovered "components" had length 4046 / 10506 - one entry per
     heartbeat, not per time sample. Here every trial is a (187 x 20) matrix
     (rows = time samples, columns = observation channels), matching the
     orientation used for the toy problem, so the components are cardiac
     waveforms on a real time axis.
  2. Resolution. Output is vector PDF, not a ~600x460 px raster.

Panels per figure: (a) components, normal; (b) components, abnormal;
(c) component scores, normal; (d) component scores, abnormal.

Run after ecg_validation.py (both read ecg_data/ptbdb_*.csv).
"""
import os
import sys
import warnings

warnings.filterwarnings("ignore")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.cluster import Birch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "lspie_src"))

from functions import prebuiltICA, innerProduct, absInnerProduct  # noqa: E402
import LSPIE  # noqa: E402

OUT = os.path.join(HERE, "paper_latex", "figures")
DATA = os.path.join(HERE, "ecg_data")

FS = 125.0                # sampling rate, Hz
N_SAMPLES = 187
N_CHANNELS = 20
N_COMPONENTS = 4
LEXP_MAXCOMP = 8
LEXP_CUTOFF = 0.1
LCON_N_CLUSTERS = 3
SEED = 12345

# Categorical slots 1,2,3,7 of the reference palette. This ordering was chosen
# by running the palette validator under --pairs all (overlaid traces are
# mutually comparable, so every pair matters, not just adjacent ones):
# all hard gates pass, worst all-pairs CVD dE 9.2, worst normal-vision dE 16.3.
# The default slot 4 (yellow #eda100) was rejected: yellow-vs-orange measures
# dE 13.7 to normal vision, below the 15 floor. Aqua carries a sub-3:1 contrast
# warning against a white surface, which the always-present legend relieves.
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#4a3aa7"]
INK = "#0b0b0b"
MUTED = "#898781"
GRID = "#e1e0d9"
AXIS = "#c3c2b7"

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["DejaVu Sans"],
    "font.size": 8,
    "axes.labelsize": 8,
    "axes.titlesize": 8.5,
    "xtick.labelsize": 7,
    "ytick.labelsize": 7,
    "legend.fontsize": 7,
    "axes.edgecolor": AXIS,
    "axes.linewidth": 0.6,
    "axes.labelcolor": INK,
    "text.color": INK,
    "xtick.color": MUTED,
    "ytick.color": MUTED,
    "xtick.major.width": 0.6,
    "ytick.major.width": 0.6,
    "grid.color": GRID,
    "grid.linewidth": 0.5,
    "legend.frameon": True, "legend.framealpha": 0.88,
    "legend.facecolor": "#ffffff", "legend.edgecolor": "none",
    "pdf.fonttype": 42,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.02,
})

T = np.arange(N_SAMPLES) / FS


def load_class(name):
    arr = np.loadtxt(os.path.join(DATA, name), delimiter=",", dtype=np.float64)
    return arr[:, :N_SAMPLES]


def make_trial(beats, rng, n_ch=N_CHANNELS):
    idx = rng.choice(beats.shape[0], size=n_ch, replace=False)
    return beats[idx].T.copy()


def none_baseline(data, n_components):
    comps = prebuiltICA(data, n_components)
    ref = data.mean(axis=1)
    scores = np.array([abs(innerProduct(ref, c)) for c in comps])
    return comps, np.abs(scores) / np.sum(np.abs(scores)) * 100


def fit_condition(condition, data):
    if condition == "none":
        return none_baseline(data, N_COMPONENTS)
    if condition == "lrs":
        proc = LSPIE.processor("LRS", prebuiltICA, innerProduct)
        proc.fit(data, N_COMPONENTS, False)
        return np.asarray(proc.components), np.asarray(proc.scores)
    if condition == "lexp":
        proc = LSPIE.processor("LEXP", prebuiltICA, innerProduct)
        proc.fit(data, LEXP_MAXCOMP, LEXP_CUTOFF, False)
        s = np.asarray(proc.scores)
        return np.asarray(proc.components), (s * 100 if np.max(s) <= 1.0001 else s)
    if condition == "lcon":
        proc = LSPIE.processor("LCON", prebuiltICA, absInnerProduct)
        proc.fit(data, Birch(n_clusters=LCON_N_CLUSTERS), 1, False)
        return np.asarray(proc.components), np.asarray(proc.scores)
    raise ValueError(condition)


def tidy(ax, grid_axis="y"):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(True, axis=grid_axis, zorder=0)
    ax.set_axisbelow(True)


def panel_label(ax, letter):
    ax.text(-0.16, 1.06, f"({letter})", transform=ax.transAxes,
            fontsize=8.5, fontweight="bold", va="bottom", ha="left", color=INK)


def peak_normalise(c):
    """Scale a component to unit peak amplitude.

    FastICA fixes neither the sign nor the scale of a recovered source, and
    LS-PIE's scaling convention multiplies components by their percentage score,
    so raw component amplitude is not a meaningful quantity to compare across
    methods - under Latent Condensing one component can exceed another by two
    orders of magnitude purely through that convention, which makes an overlay
    unreadable. Shape is what the component panel is for; magnitude is carried by
    the score panel beside it.
    """
    c = np.asarray(c, dtype=float).ravel()
    peak = np.max(np.abs(c))
    return c / peak if peak > 0 else c


def plot_components(ax, comps, title):
    comps = np.atleast_2d(np.asarray(comps))
    for i, c in enumerate(comps):
        ax.plot(T, peak_normalise(c), color=SERIES[i % len(SERIES)],
                linewidth=1.0, label=f"Component {i+1}", zorder=3)
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Amplitude (peak-normalised)")
    ax.set_ylim(-1.25, 1.55)
    ax.set_title(title, color=INK)
    ax.set_xlim(T[0], T[-1])
    ax.legend(loc="upper right", handlelength=1.4, labelspacing=0.2, borderpad=0.25,
              fontsize=6.5)
    tidy(ax)


def plot_scores(ax, scores, title):
    s = np.asarray(scores, dtype=float).ravel()
    idx = np.arange(1, len(s) + 1)
    ax.bar(idx, s, width=0.62,
           color=[SERIES[(i) % len(SERIES)] for i in range(len(s))], zorder=3)
    for i, v in zip(idx, s):
        ax.text(i, v, f"{v:.1f}", ha="center", va="bottom", fontsize=6.5, color=INK)
    ax.set_xlabel("Component")
    ax.set_ylabel("Score (\\%)" if False else "Score (%)")
    ax.set_title(title, color=INK)
    ax.set_xticks(idx)
    ax.set_ylim(0, max(s) * 1.18)
    tidy(ax)


def figure_condition(condition, trials, filename, titles):
    fig, axes = plt.subplots(2, 2, figsize=(7.0, 4.9))
    (ax_a, ax_b), (ax_c, ax_d) = axes
    out = {}
    for ax_comp, ax_score, key, letters in (
        (ax_a, ax_c, "normal", ("a", "c")),
        (ax_b, ax_d, "abnormal", ("b", "d")),
    ):
        comps, scores = fit_condition(condition, trials[key])
        out[key] = (comps, scores)
        plot_components(ax_comp, comps, titles[key])
        plot_scores(ax_score, scores, titles[key])
        panel_label(ax_comp, letters[0])
        panel_label(ax_score, letters[1])
    fig.tight_layout(w_pad=2.0, h_pad=2.2)
    path = os.path.join(OUT, filename)
    fig.savefig(path)
    plt.close(fig)
    n = {k: len(np.atleast_1d(v[1])) for k, v in out.items()}
    print(f"  {filename}: components retained {n}")
    return out


def main():
    os.makedirs(OUT, exist_ok=True)
    rng = np.random.default_rng(SEED)
    np.random.seed(SEED)

    normal = load_class("ptbdb_normal.csv")
    abnormal = load_class("ptbdb_abnormal.csv")
    print(f"normal {normal.shape}  abnormal {abnormal.shape}")

    trials = {"normal": make_trial(normal, rng), "abnormal": make_trial(abnormal, rng)}
    titles = {"normal": "Normal (ptbdb\\_normal)" if False else "Normal",
              "abnormal": "Abnormal"}

    # ---- Figure 9: example inputs -------------------------------------
    fig, (axl, axr) = plt.subplots(1, 2, figsize=(7.0, 2.5))
    for ax, X, name, letter in ((axl, trials["normal"], "Normal", "a"),
                                (axr, trials["abnormal"], "Abnormal", "b")):
        for j in range(X.shape[1]):
            ax.plot(T, X[:, j], color=SERIES[0], linewidth=0.5, alpha=0.30, zorder=2)
        ax.plot(T, X[:, 0], color=SERIES[0], linewidth=1.3, zorder=4)
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("Normalised amplitude")
        ax.set_title(f"{name} heartbeats", color=INK)
        ax.set_xlim(T[0], T[-1])
        panel_label(ax, letter)
        tidy(ax)
    fig.tight_layout(w_pad=2.0)
    fig.savefig(os.path.join(OUT, "fig9_ecg_input.pdf"))
    plt.close(fig)
    print("  fig9_ecg_input.pdf")

    # ---- Figures 10-13: one per condition ------------------------------
    figure_condition("none", trials, "fig10_raw_ica.pdf", titles)
    figure_condition("lrs",  trials, "fig11_ranked_scaling.pdf", titles)
    figure_condition("lexp", trials, "fig12_latent_expansion.pdf", titles)
    figure_condition("lcon", trials, "fig13_latent_condensing.pdf", titles)


if __name__ == "__main__":
    main()
