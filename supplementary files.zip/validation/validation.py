"""
Reproducible statistical validation + quantitative metrics for the LS-PIE
revision, generated entirely from the code published on the LS-PIE-2026
branch (LSPIE.py / functions.py / datagen.py) that the paper cites as its
Supplementary Material.

This script does NOT touch the private ECG dataset (not present in the
repository - hardcoded local path in the authors' notebook). Instead it
builds a fully reproducible two-class synthetic validation directly from
datagen.paperExamplegen's generator (the same generator already used for
Figures 4-8), and reports:

  1. A Table-1 replacement: Mann-Whitney U and Welch t-test statistics
     comparing a "sawtooth-class" vs "sinusoid-class" population of
     independent trials, under None / Ranked Scaling (LRS) / Latent
     Expansion (LEXP) / Latent Condensing (LCON), using the paper's stated
     methodology (15 repeated sub-samples of 500 trials, scipy.stats,
     Welch-Satterthwaite dof).
  2. Runtime per method (wall-clock, mean +/- std over repeats).
  3. Compression ratio (# retained components / # initially solved).
  4. Source-recovery correlation: |corr| between each method's top-ranked
     recovered component and the two known ground-truth sources
     (sinusoid, sawtooth), which is the appropriate "recovery quality"
     metric for a blind-source-separation post-processing framework.

All numbers are printed as JSON to stdout and written to
validation_results.json.
"""
import warnings
warnings.filterwarnings("ignore")

import json
import time
import numpy as np
from scipy import signal as spsignal
from scipy import stats as spstats
from sklearn.cluster import Birch

from functions import prebuiltICA, innerProduct, absInnerProduct
import LSPIE

RNG_SEED = 12345
T = np.linspace(0, 1, 800)
N_CHANNELS = 20          # channels ("mixed observations") per trial matrix, matches Fig 4-8 setup
N_COMPONENTS = 4          # matches "we restrict it to four components" (ECG section)
NOISE_SCALE = 0.3
N_BOOT = 1000             # independent trial-matrices per class (bootstrap pool)
N_SUBSAMPLE_SETS = 15     # matches paper's stated methodology
SUBSAMPLE_SIZE = 500      # matches paper's stated methodology
LEXP_MAXCOMP = 8
LEXP_CUTOFF = 0.1
LCON_N_CLUSTERS = 3


def gen_class_matrix(kind, rng, n_ch=N_CHANNELS, noise_scale=NOISE_SCALE):
    """One (800 x n_ch) matrix of independent trials of a single kind
    ('saw' or 'sin'), each with an independent random scale + noise draw -
    identical generation logic to datagen.paperExamplegen, but producing a
    single-kind population instead of a 50/50 mix."""
    cols = []
    for _ in range(n_ch):
        scaler = rng.random()
        noise = rng.random(len(T)) * noise_scale
        if kind == "saw":
            sig = spsignal.sawtooth(2 * np.pi * 3 * T) * scaler + noise
        else:
            sig = np.sin(2 * np.pi * T) * scaler + noise
        cols.append(sig)
    return np.array(cols).T


def none_baseline(data, n_components, rng_state):
    """'None' row: raw FastICA components, scored but NOT ranked/scaled/clustered."""
    comps = prebuiltICA(data, n_components)  # shape (n_components, n_channels)
    scores = np.array([abs(innerProduct(data[:, 0] * 0 + 1, c)) for c in comps])
    # score each component against the aggregate channel-mean signal (unranked, unscaled)
    ref = data.mean(axis=1)
    scores = np.array([abs(innerProduct(ref, c)) for c in comps])
    tot = np.sum(np.abs(scores))
    scores = np.abs(scores) / tot * 100
    return comps, scores


def top_k_scores(scores, k=N_COMPONENTS):
    s = np.sort(np.asarray(scores))[::-1]
    out = np.full(k, np.nan)
    out[: min(k, len(s))] = s[: min(k, len(s))]
    return out


def run_condition(condition, data, rng_state):
    if condition == "None":
        _, scores = none_baseline(data, N_COMPONENTS, rng_state)
    elif condition == "Ranked Scaling":
        proc = LSPIE.processor("LRS", prebuiltICA, innerProduct)
        proc.fit(data, N_COMPONENTS, False)
        scores = proc.scores
    elif condition == "Latent Expansion":
        proc = LSPIE.processor("LEXP", prebuiltICA, innerProduct)
        proc.fit(data, LEXP_MAXCOMP, LEXP_CUTOFF, False)
        scores = proc.scores * 100 if np.max(proc.scores) <= 1.0001 else proc.scores
    elif condition == "Latent Condensing":
        cmodel = Birch(n_clusters=LCON_N_CLUSTERS)
        proc = LSPIE.processor("LCON", prebuiltICA, absInnerProduct)
        proc.fit(data, cmodel, 1, False)
        scores = proc.scores
    else:
        raise ValueError(condition)
    return top_k_scores(scores)


def welch_stats(a, b):
    a = a[~np.isnan(a)]
    b = b[~np.isnan(b)]
    if len(a) < 2 or len(b) < 2:
        return dict(t=np.nan, p=np.nan, df=np.nan, d=np.nan, n1=len(a), n2=len(b))
    res = spstats.ttest_ind(a, b, equal_var=False)
    # Welch-Satterthwaite dof
    v1, v2 = np.var(a, ddof=1), np.var(b, ddof=1)
    n1, n2 = len(a), len(b)
    df = (v1 / n1 + v2 / n2) ** 2 / ((v1 / n1) ** 2 / (n1 - 1) + (v2 / n2) ** 2 / (n2 - 1))
    # Cohen's d (unequal-variance form: mean diff over the RMS of the two SDs)
    d = (np.mean(a) - np.mean(b)) / np.sqrt((v1 + v2) / 2)
    return dict(t=float(res.statistic), p=float(res.pvalue), df=float(df),
                d=float(d), n1=n1, n2=n2)


def mwu_stats(a, b):
    a = a[~np.isnan(a)]
    b = b[~np.isnan(b)]
    if len(a) < 2 or len(b) < 2:
        return dict(U=np.nan, p=np.nan, r_rb=np.nan, n1=len(a), n2=len(b))
    res = spstats.mannwhitneyu(a, b, alternative="two-sided")
    n1, n2 = len(a), len(b)
    r_rb = 1 - (2 * float(res.statistic)) / (n1 * n2)  # rank-biserial correlation
    return dict(U=float(res.statistic), p=float(res.pvalue), r_rb=float(r_rb), n1=n1, n2=n2)


def main():
    # FastICA and Birch are constructed without an explicit random_state, so they
    # draw from numpy's global RNG. Seeding it here (in addition to the Generator
    # used for data synthesis) is what makes the reported table reproducible run
    # to run; without it the statistics move by a few percent on every execution.
    np.random.seed(RNG_SEED)
    rng = np.random.default_rng(RNG_SEED)
    conditions = ["None", "Ranked Scaling", "Latent Expansion", "Latent Condensing"]

    # ---- 1. Bootstrap pool of per-trial top-k scores for each class x condition ----
    pool = {c: {"saw": np.full((N_BOOT, N_COMPONENTS), np.nan),
                "sin": np.full((N_BOOT, N_COMPONENTS), np.nan)}
            for c in conditions}

    runtime = {c: [] for c in conditions}

    t_start = time.time()
    for i in range(N_BOOT):
        A = gen_class_matrix("saw", rng)
        B = gen_class_matrix("sin", rng)
        for c in conditions:
            t0 = time.time()
            pool[c]["saw"][i] = run_condition(c, A, rng)
            runtime[c].append(time.time() - t0)
            t0 = time.time()
            pool[c]["sin"][i] = run_condition(c, B, rng)
            runtime[c].append(time.time() - t0)
    print(f"# bootstrap pool built in {time.time()-t_start:.1f}s", flush=True)

    # ---- 2. Paper's stated procedure: 15 subsamples of 500, per component column ----
    table = {}
    for c in conditions:
        mwu_runs = {k: [] for k in range(N_COMPONENTS)}
        tt_runs = {k: [] for k in range(N_COMPONENTS)}
        for s in range(N_SUBSAMPLE_SETS):
            idx_saw = rng.choice(N_BOOT, size=SUBSAMPLE_SIZE, replace=False)
            idx_sin = rng.choice(N_BOOT, size=SUBSAMPLE_SIZE, replace=False)
            for k in range(N_COMPONENTS):
                a = pool[c]["saw"][idx_saw, k]
                b = pool[c]["sin"][idx_sin, k]
                mwu_runs[k].append(mwu_stats(a, b))
                tt_runs[k].append(welch_stats(a, b))
        table[c] = {"mwu": {}, "ttest": {}}
        for k in range(N_COMPONENTS):
            Us = [r["U"] for r in mwu_runs[k] if not np.isnan(r["U"])]
            Ps = [r["p"] for r in mwu_runs[k] if not np.isnan(r["p"])]
            Rs = [r["r_rb"] for r in mwu_runs[k] if not np.isnan(r.get("r_rb", np.nan))]
            Ns = [(r["n1"], r["n2"]) for r in mwu_runs[k] if not np.isnan(r["U"])]
            table[c]["mwu"][k] = dict(
                U_median=float(np.median(Us)) if Us else None,
                p_median=float(np.median(Ps)) if Ps else None,
                p_min=float(np.min(Ps)) if Ps else None,
                p_max=float(np.max(Ps)) if Ps else None,
                r_rb_median=float(np.median(Rs)) if Rs else None,
                n_median=float(np.median([n[0] for n in Ns])) if Ns else None,
            )
            Ts = [r["t"] for r in tt_runs[k] if not np.isnan(r["t"])]
            Pt = [r["p"] for r in tt_runs[k] if not np.isnan(r["p"])]
            Dt = [r["df"] for r in tt_runs[k] if not np.isnan(r["df"])]
            Cd = [r["d"] for r in tt_runs[k] if not np.isnan(r.get("d", np.nan))]
            Nt = [(r["n1"], r["n2"]) for r in tt_runs[k] if not np.isnan(r["t"])]
            table[c]["ttest"][k] = dict(
                t_median=float(np.median(Ts)) if Ts else None,
                p_median=float(np.median(Pt)) if Pt else None,
                p_min=float(np.min(Pt)) if Pt else None,
                p_max=float(np.max(Pt)) if Pt else None,
                df_median=float(np.median(Dt)) if Dt else None,
                d_median=float(np.median(Cd)) if Cd else None,
                n_median=float(np.median([n[0] for n in Nt])) if Nt else None,
            )

        # Holm-Bonferroni correction across the (up to 4) component comparisons
        # within this condition, applied to the median p-value of each family.
        for test in ("mwu", "ttest"):
            entries = [(k, table[c][test][k]["p_median"]) for k in range(N_COMPONENTS)
                       if table[c][test][k]["p_median"] is not None]
            entries.sort(key=lambda kv: kv[1])
            m = len(entries)
            for rank, (k, p) in enumerate(entries):
                p_holm = min(1.0, p * (m - rank))
                table[c][test][k]["p_holm"] = float(p_holm)

    # ---- 3. Runtime summary ----
    runtime_summary = {
        c: dict(mean_ms=float(np.mean(runtime[c]) * 1000),
                std_ms=float(np.std(runtime[c]) * 1000))
        for c in conditions
    }

    # ---- 4. Compression ratio + source-recovery correlation (single representative run) ----
    rng2 = np.random.default_rng(999)
    A = gen_class_matrix("saw", rng2)
    B = gen_class_matrix("sin", rng2)
    true_saw = spsignal.sawtooth(2 * np.pi * 3 * T)
    true_sin = np.sin(2 * np.pi * T)

    def best_corr(component, truth):
        c = np.corrcoef(component, truth)[0, 1]
        return abs(c)

    recovery = {}
    compression = {}
    for c in conditions:
        for label, data, truth in [("saw", A, true_saw), ("sin", B, true_sin)]:
            if c == "None":
                comps, scores = none_baseline(data, N_COMPONENTS, rng2)
            elif c == "Ranked Scaling":
                proc = LSPIE.processor("LRS", prebuiltICA, innerProduct)
                proc.fit(data, N_COMPONENTS, False)
                comps, scores = proc.components, proc.scores
            elif c == "Latent Expansion":
                proc = LSPIE.processor("LEXP", prebuiltICA, innerProduct)
                proc.fit(data, LEXP_MAXCOMP, LEXP_CUTOFF, False)
                comps, scores = proc.components, proc.scores
            elif c == "Latent Condensing":
                cmodel = Birch(n_clusters=LCON_N_CLUSTERS)
                proc = LSPIE.processor("LCON", prebuiltICA, absInnerProduct)
                proc.fit(data, cmodel, 1, False)
                comps, scores = proc.components, proc.scores
            top_idx = int(np.argmax(scores))
            top_comp = np.asarray(comps[top_idx]).ravel()
            recovery[f"{c}|{label}"] = best_corr(top_comp, truth)
            # n_initial_request is the number of components the LVM is actually
            # asked for, which is NOT N_COMPONENTS for LCON: fitLCON requests
            # min(shape(X)) = N_CHANNELS regardless of the caller's setting.
            if c == "Latent Expansion":
                n_request = LEXP_MAXCOMP
            elif c == "Latent Condensing":
                n_request = N_CHANNELS
            else:
                n_request = N_COMPONENTS
            compression[f"{c}|{label}"] = dict(
                n_solved=N_COMPONENTS if c in ("None", "Ranked Scaling") else len(scores),
                n_initial_request=n_request,
            )

    results = dict(
        meta=dict(seed=RNG_SEED, n_boot=N_BOOT, n_subsample_sets=N_SUBSAMPLE_SETS,
                   subsample_size=SUBSAMPLE_SIZE, n_channels=N_CHANNELS,
                   n_components=N_COMPONENTS, lexp_maxcomp=LEXP_MAXCOMP,
                   lexp_cutoff=LEXP_CUTOFF, lcon_n_clusters=LCON_N_CLUSTERS),
        table=table,
        runtime_ms=runtime_summary,
        recovery_correlation=recovery,
        compression=compression,
    )
    with open("validation_results.json", "w") as f:
        json.dump(results, f, indent=2)
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
