"""Regenerate Figures 4-8 (the toy problem) as publication-quality vector PDFs.

The figures embedded in the DOCX were ~600x460 px rasters with unreadable tick
labels. These are vector PDFs built from the same generator the paper cites,
datagen.paperExamplegen, using the same conditions as make_ecg_figures.py so the
two demonstrations are presented identically.

Writes into paper_latex/figures/.
"""
import os
import sys
import warnings

warnings.filterwarnings("ignore")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy import signal as spsignal
from sklearn.cluster import Birch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "lspie_src"))

from functions import prebuiltICA, innerProduct, absInnerProduct  # noqa: E402
import LSPIE  # noqa: E402

OUT = os.path.join(HERE, "paper_latex", "figures")

SEED = 12345
T = np.linspace(0, 1, 800)
N_CHANNELS = 20
NOISE_SCALE = 0.3
N_COMPONENTS = 4
LEXP_MAXCOMP = 8
LEXP_CUTOFF = 0.1
LCON_N_CLUSTERS = 3

# same validated slots as make_ecg_figures.py
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#4a3aa7"]
INK, MUTED, GRID, AXIS = "#0b0b0b", "#898781", "#e1e0d9", "#c3c2b7"

plt.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["DejaVu Sans"],
    "font.size": 8, "axes.labelsize": 8, "axes.titlesize": 8.5,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7,
    "axes.edgecolor": AXIS, "axes.linewidth": 0.6, "axes.labelcolor": INK,
    "text.color": INK, "xtick.color": MUTED, "ytick.color": MUTED,
    "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "grid.color": GRID, "grid.linewidth": 0.5, "legend.frameon": True, "legend.framealpha": 0.88,
    "legend.facecolor": "#ffffff", "legend.edgecolor": "none",
    "pdf.fonttype": 42, "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
})

TRUE_SAW = spsignal.sawtooth(2 * np.pi * 3 * T)
TRUE_SIN = np.sin(2 * np.pi * T)


def paper_example(n, rng):
    """The generation logic of datagen.paperExamplegen: half scaled sawtooths,
    half scaled sinusoids, each with independent noise, stacked as columns."""
    half = int(np.round(n / 2))
    cols = []
    for _ in range(half):
        scaler = rng.random()
        cols.append(TRUE_SAW * scaler + rng.random(len(T)) * NOISE_SCALE)
    for _ in range(half):
        scaler = rng.random()
        cols.append(TRUE_SIN * scaler + rng.random(len(T)) * NOISE_SCALE)
    return np.array(cols).T


def none_baseline(data, n):
    comps = prebuiltICA(data, n)
    ref = data.mean(axis=1)
    s = np.array([abs(innerProduct(ref, c)) for c in comps])
    return comps, np.abs(s) / np.sum(np.abs(s)) * 100


def fit_condition(condition, data):
    if condition == "none":
        return none_baseline(data, N_COMPONENTS)
    if condition == "lrs":
        proc = LSPIE.processor("LRS", prebuiltICA, innerProduct)
        proc.fit(data, N_COMPONENTS, False)
    elif condition == "lcon":
        proc = LSPIE.processor("LCON", prebuiltICA, absInnerProduct)
        proc.fit(data, Birch(n_clusters=LCON_N_CLUSTERS), 1, False)
    elif condition == "lexp":
        proc = LSPIE.processor("LEXP", prebuiltICA, innerProduct)
        proc.fit(data, LEXP_MAXCOMP, LEXP_CUTOFF, False)
        s = np.asarray(proc.scores)
        return np.asarray(proc.components), (s * 100 if np.max(s) <= 1.0001 else s)
    else:
        raise ValueError(condition)
    return np.asarray(proc.components), np.asarray(proc.scores)


def tidy(ax, axis="y"):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(True, axis=axis, zorder=0)
    ax.set_axisbelow(True)


def panel_label(ax, letter):
    ax.text(-0.14, 1.06, f"({letter})", transform=ax.transAxes, fontsize=8.5,
            fontweight="bold", va="bottom", ha="left", color=INK)


def peak_normalise(c):
    """Scale a component to unit peak amplitude; see make_ecg_figures.py for why."""
    c = np.asarray(c, dtype=float).ravel()
    peak = np.max(np.abs(c))
    return c / peak if peak > 0 else c


def two_panel(comps, scores, filename, comp_title, score_title):
    fig, (axl, axr) = plt.subplots(1, 2, figsize=(7.0, 2.6))
    comps = np.atleast_2d(np.asarray(comps))
    for i, c in enumerate(comps):
        axl.plot(T, peak_normalise(c), color=SERIES[i % len(SERIES)],
                 linewidth=0.9, label=f"Component {i+1}", zorder=3)
    axl.set_xlabel("Time (s)")
    axl.set_ylabel("Amplitude (peak-normalised)")
    axl.set_ylim(-1.25, 1.55)
    axl.set_title(comp_title, color=INK)
    axl.set_xlim(T[0], T[-1])
    axl.legend(loc="upper right", handlelength=1.4, labelspacing=0.2, borderpad=0.25,
               fontsize=6.5)
    panel_label(axl, "a")
    tidy(axl)

    s = np.asarray(scores, dtype=float).ravel()
    idx = np.arange(1, len(s) + 1)
    axr.bar(idx, s, width=0.62, color=[SERIES[i % len(SERIES)] for i in range(len(s))],
            zorder=3)
    for i, v in zip(idx, s):
        axr.text(i, v, f"{v:.1f}", ha="center", va="bottom", fontsize=6.5, color=INK)
    axr.set_xlabel("Component")
    axr.set_ylabel("Score (%)")
    axr.set_title(score_title, color=INK)
    axr.set_xticks(idx)
    axr.set_ylim(0, max(s) * 1.18)
    panel_label(axr, "b")
    tidy(axr)

    fig.tight_layout(w_pad=2.0)
    fig.savefig(os.path.join(OUT, filename))
    plt.close(fig)
    print(f"  {filename}: {len(s)} components")


def main():
    os.makedirs(OUT, exist_ok=True)
    rng = np.random.default_rng(SEED)
    np.random.seed(SEED)
    data = paper_example(N_CHANNELS, rng)

    # ---- Figure 4: the sources and the mixed observations ----------------
    fig, (axl, axr) = plt.subplots(1, 2, figsize=(7.0, 2.6))
    axl.plot(T, TRUE_SAW, color=SERIES[0], linewidth=1.1, label="Sawtooth", zorder=3)
    axl.plot(T, TRUE_SIN, color=SERIES[1], linewidth=1.1, label="Sinusoid", zorder=3)
    axl.set_xlabel("Time (s)")
    axl.set_ylabel("Amplitude")
    axl.set_title("Ground-truth sources", color=INK)
    axl.set_xlim(T[0], T[-1])
    axl.legend(loc="upper right", handlelength=1.4, labelspacing=0.2, borderpad=0.25,
               fontsize=6.5)
    panel_label(axl, "a")
    tidy(axl)

    for j in range(data.shape[1]):
        axr.plot(T, data[:, j], color=SERIES[0], linewidth=0.4, alpha=0.28, zorder=2)
    axr.plot(T, data[:, 0], color=SERIES[0], linewidth=1.1, zorder=4)
    axr.set_xlabel("Time (s)")
    axr.set_ylabel("Amplitude")
    axr.set_title(f"The {N_CHANNELS} mixed observations", color=INK)
    axr.set_xlim(T[0], T[-1])
    panel_label(axr, "b")
    tidy(axr)
    fig.tight_layout(w_pad=2.0)
    fig.savefig(os.path.join(OUT, "fig4_toy_input.pdf"))
    plt.close(fig)
    print("  fig4_toy_input.pdf")

    for cond, fname, title in (
        ("none", "fig5_toy_raw_ica.pdf", "Raw FastICA"),
        ("lrs",  "fig6_toy_ranked_scaling.pdf", "Ranked Scaling"),
        ("lcon", "fig7_toy_condensing.pdf", "Latent Condensing"),
        ("lexp", "fig8_toy_expansion.pdf", "Latent Expansion"),
    ):
        comps, scores = fit_condition(cond, data)
        two_panel(comps, scores, fname, title, title)


if __name__ == "__main__":
    main()
